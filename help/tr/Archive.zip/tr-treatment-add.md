
# Hasta Planına İşlem Ekleme

Bir hasta için tedavi planı oluştururken yapılacak ilk adımdır.

**Yol:** `Hastalar > [Hasta Adı] > Tedavi`

## Adım Adım Ekleme

1.  **Tedavi** sekmesindeki arama çubuğuna yapılacak işlemi yazın (Örn: Dolgu).
2.  Diş şemasından işlem tedavi uygulanacak dişleri seçin
3.  Listeden ilgili tedaviyi bulun.  
4.  Tedavinin üzerine **tıklayın**.

İşlem anında listeye yeni bir satır olarak eklenir. Aynı işlemi birden fazla kez eklemek için (örn. 3 diş için) tekrar tıklayabilirsiniz.

> 👉 **Sıradaki Adım:** İşlemleri gruplamak için [Faz (Aşama) Yönetimi](/Tedavi/faz-yonetimi) dokümanına bakabilirsiniz.